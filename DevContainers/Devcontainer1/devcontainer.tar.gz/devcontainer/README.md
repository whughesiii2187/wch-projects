# Dev Container

A reproducible, language-agnostic development environment running inside Podman via the devcontainer CLI, with Neovim pre-configured for each installed language.

Currently ships with **Go** and **Odin**. Adding Python, Rust, or anything else is a matter of uncommenting a block in the Dockerfile and dropping a plugin file in `nvim/lua/plugins/`.

## Prerequisites

| Tool | Install |
|------|---------|
| Podman (rootless) | `dnf install podman` / `apt install podman` |
| devcontainer CLI | `npm i -g @devcontainers/cli` |
| Node ≥ 18 | (for devcontainer CLI) |

```bash
podman info --format '{{.Host.Security.Rootless}}'   # should print true
```

---

## Quick start

```bash
make build      # build the image
make pod-up     # start devcontainer + Postgres sidecar
make pod-shell  # open a shell inside the container
make pod-nvim   # open neovim inside the container
```

---

## Adding a language

1. **Dockerfile** — add an install section following the existing Go/Odin pattern. Stub sections for Python and Rust are already in the file, commented out.
2. **Neovim** — add a file to `.devcontainer/nvim/lua/plugins/` wiring up the LSP and any language-specific plugins.
3. Rebuild: `make rebuild`

---

## What's inside

### Base
- **Image**: `debian:bookworm-slim`
- **Shell**: `zsh` + `tmux`
- **Editor**: Neovim (latest stable)
- **Search**: `ripgrep`, `fd`, `fzf`
- **Database client**: `psql` (Postgres server runs as a sidecar)

### Languages

#### Go
| Tool | Purpose |
|------|---------|
| `gopls` | LSP server |
| `dlv` | Delve debugger |
| `goimports` | Import management |
| `gofumpt` | Formatter |
| `golangci-lint` | Multi-linter |
| `gomodifytags` | Struct tag management |
| `impl` | Interface stub generation |

#### Odin
| Tool | Purpose |
|------|---------|
| `odin` | Compiler (latest nightly) |
| `ols` | Language server |
| `odinfmt` | Formatter |

### Neovim plugins
| Plugin | Purpose |
|--------|---------|
| `lazy.nvim` | Plugin manager |
| `nvim-lspconfig` + `mason` | LSP management |
| `nvim-cmp` | Autocompletion |
| `ray-x/go.nvim` | Go IDE features |
| `nvim-dap` + `nvim-dap-go` | Debugger |
| `neotest-golang` | Test runner UI |
| `Tetralux/odin.vim` | Odin filetype + syntax |
| `telescope.nvim` | Fuzzy finder |
| `nvim-treesitter` | Syntax highlighting |
| `trouble.nvim` | Diagnostics list |
| `kanagawa` | Colorscheme |

---

## Postgres sidecar

Postgres runs as a separate container in the same pod, reachable at `localhost:5432`.

| Setting | Value |
|---------|-------|
| User | `dev` |
| Password | `dev` |
| Database | `devdb` |
| `DATABASE_URL` | `postgres://dev:dev@localhost:5432/devdb?sslmode=disable` |

Data is persisted in a named volume and survives pod restarts.

For Odin projects, copy `ols.json` from the repo root into your project root to activate the language server.

---

## Makefile targets

```
make build      — build the container image
make pod-up     — start the full pod (devcontainer + Postgres)
make pod-down   — stop and remove the pod
make pod-shell  — open zsh inside the devcontainer
make pod-nvim   — open neovim inside the devcontainer
make pg-cli     — connect to Postgres via psql from the host
make up         — start via devcontainer CLI (no sidecar)
make shell      — shell via devcontainer CLI
make rebuild    — rebuild image without cache
make prune      — remove dangling images and volumes
```
