# Local SQL Server lab (Docker + StackOverflow2010)

A disposable SQL Server 2022 instance, pre-loaded with the StackOverflow2010
dataset (real Stack Overflow data from 2008–2010, ~10GB once attached).
Everything lives in this one folder — delete it and re-run `setup.sh` to
get back to a clean state any time.

## What's here

- `docker-compose.yml` — the SQL Server 2022 (Developer edition, free) container
- `.env` — the `sa` password used by both the container and the setup script
- `setup.sh` — downloads the dataset, starts the container, attaches the DB

## Prerequisites

- Docker Engine (you've already got this)
- `p7zip` to extract the dataset: `sudo dnf install p7zip p7zip-plugins`
- ~11GB free disk space

## Quick start

```bash
chmod +x setup.sh
./setup.sh
```

First run downloads ~1GB, extracts to ~10GB, and attaches it — a few
minutes depending on your connection. Subsequent runs are near-instant
(everything is skipped once it's already in place).

## Connecting

- **Server:** `localhost,1433`
- **Login:** `sa`
- **Password:** whatever is in `.env`
- **Database:** `StackOverflow2010`

From the command line, without leaving the container:

```bash
docker compose exec mssql /opt/mssql-tools18/bin/sqlcmd \
  -S localhost -U sa -P "$(grep SA_PASSWORD .env | cut -d= -f2)" \
  -C -d StackOverflow2010
```

For a GUI, any of these will connect to `localhost:1433` fine:
[Azure Data Studio](https://azure.microsoft.com/products/data-studio)
(free, made for this), [DBeaver](https://dbeaver.io/) (free, works with
everything), or VS Code's **SQL Server (mssql)** extension if you'd rather
stay in one editor. Pick whichever fits how you like to work — none of
them need extra config beyond the connection details above.

## Resetting to a clean slate

```bash
docker compose down -v   # stops the container, deletes its data volume
rm -rf stackoverflow-data
./setup.sh                # rebuilds everything from scratch
```

## Notes and gotchas

- **Fedora + SELinux:** the `:Z` suffix on the `stackoverflow-data` volume
  in `docker-compose.yml` relabels the folder for container access. If you
  ever add more bind mounts, they'll need the same suffix or you'll hit
  `Permission denied` errors reading files that are clearly there.
- **The `.mdf`/`.ldf` are from a much older SQL Server version.** SQL
  Server 2022 attaches and auto-upgrades databases from as far back as
  SQL Server 2005 (compatibility level 90+), so this works without any
  intermediate hop — no need to attach it to an older SQL Server first.
- **License:** the dataset is Stack Exchange's public data dump
  (CC BY-SA 4.0), repackaged by Brent Ozar Unlimited for easy download.
- **Want the bigger datasets later?** Brent Ozar also publishes a ~50GB
  (`StackOverflow2013`) and a ~200GB version via BitTorrent, same schema,
  more data to make slow queries genuinely slow — useful once you're past
  basics and want to feel query performance differences.
