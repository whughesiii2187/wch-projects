#!/usr/bin/env bash
# One-shot setup for the local SQL Server learning lab.
#
# Safe to re-run: skips the download if the data file already exists,
# and skips the attach if the database is already attached.
#
# Full reset: docker compose down -v && rm -rf stackoverflow-data && ./setup.sh
set -euo pipefail
cd "$(dirname "$0")"

# shellcheck disable=SC1091
source .env

DATA_DIR="./stackoverflow-data"
mkdir -p "$DATA_DIR"

if ! compgen -G "$DATA_DIR"/*.mdf > /dev/null; then
  echo "==> Downloading StackOverflow2010 (~1GB compressed, ~10GB extracted)"
  curl -L --fail -o "$DATA_DIR/StackOverflow2010.7z" \
    "http://downloads.brentozar.com.s3.amazonaws.com/StackOverflow2010.7z"

  echo "==> Extracting (requires p7zip: sudo dnf install p7zip p7zip-plugins)"
  7z x "$DATA_DIR/StackOverflow2010.7z" -o"$DATA_DIR" -y

  echo "==> Opening up permissions for the container's mssql user"
  chmod -R a+rwX "$DATA_DIR"
else
  echo "==> Data files already present in $DATA_DIR, skipping download"
fi

MDF_FILE=$(find "$DATA_DIR" -iname "*.mdf" | head -n1)
LDF_FILE=$(find "$DATA_DIR" -iname "*.ldf" | head -n1)

if [ -z "$MDF_FILE" ] || [ -z "$LDF_FILE" ]; then
  echo "Could not find an extracted .mdf/.ldf pair in $DATA_DIR" >&2
  exit 1
fi
MDF_NAME=$(basename "$MDF_FILE")
LDF_NAME=$(basename "$LDF_FILE")

echo "==> Starting SQL Server container"
docker compose up -d

echo "==> Waiting for SQL Server to accept connections"
until docker compose exec -T mssql /opt/mssql-tools18/bin/sqlcmd \
    -S localhost -U sa -P "$SA_PASSWORD" -C -Q "SELECT 1" >/dev/null 2>&1; do
  sleep 2
done

echo "==> Attaching StackOverflow2010 (no-op if already attached)"
docker compose exec -T mssql /opt/mssql-tools18/bin/sqlcmd \
  -S localhost -U sa -P "$SA_PASSWORD" -C -Q "
IF DB_ID('StackOverflow2010') IS NULL
BEGIN
  CREATE DATABASE StackOverflow2010 ON
    (FILENAME = '/stackoverflow-data/$MDF_NAME'),
    (FILENAME = '/stackoverflow-data/$LDF_NAME')
  FOR ATTACH;
END"

echo "==> Ready. Verify with:"
echo "docker compose exec mssql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P \"$SA_PASSWORD\" -C -d StackOverflow2010 -Q \"SELECT COUNT(*) FROM dbo.Users;\""
