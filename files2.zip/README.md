# Windows-in-Docker, just for SSMS

A Windows 11 VM that runs inside a Docker container ([dockur/windows](https://github.com/dockur/windows) —
this is the same underlying project Omarchy's own "Install > Windows" menu
item uses under the hood, minus its Hyprland/RDP wrapper). You start it when
you need SSMS, stop it when you don't. Windows and SSMS stay installed on
disk between sessions — only the container itself is what's "ephemeral"
here, spun up and torn down as needed.

## Before you start

Check your CPU/kernel actually support KVM (dockur/windows needs it):

```bash
ls -l /dev/kvm && lscpu | grep -i virtualization
```

If `/dev/kvm` doesn't exist, virtualization (VT-x/AMD-V) is probably off in
your BIOS/UEFI. Also want ~45GB free disk space (40GB for Windows +
overhead).

## Quick start

```bash
docker compose up -d
```

Open **http://localhost:8006** in your browser. Log in with
`docker` / `changeme123!` (from `docker-compose.yml` — change it before
your first run if you want). You'll watch Windows 11 install itself,
fully unattended — 20-30 minutes, no clicking required. Once you see the
desktop, you're done with the browser viewer for anything but glancing at
the VM; it has no clipboard and middling picture quality, which is the
tradeoff for zero setup.

## Installing SSMS

Inside the Windows desktop, open Edge and go to:

**https://aka.ms/ssms**

That's Microsoft's current official link — it downloads `vs_SSMS.exe`
(SSMS 22), a small bootstrapper that pulls the rest via the Visual Studio
Installer. Run it, accept the defaults. Takes a few minutes.

## Connecting to your SQL Server container

Your `sql-lab` container (from the earlier setup) is still just a
container on the same Docker host — the Windows VM reaches it the same
way it'd reach any service on your Fedora machine, using the hostname
dockur/windows exposes for exactly this purpose:

- **Server name:** `host.lan,1433`
- **Authentication:** SQL Server Authentication
- **Login:** `sa`
- **Password:** whatever's in `sql-lab`'s `.env`

Make sure `sql-lab` is actually running first (`docker compose up -d` in
that other folder) — `host.lan` reaches your Fedora machine, but nothing's
listening on 1433 unless that container is up.

## Stopping and restarting

```bash
docker compose down     # stops the VM, keeps windows-disk/ (Windows + SSMS stay installed)
docker compose up -d    # boots straight back to the desktop, no reinstall — much faster than the first run
```

## Full wipe

```bash
docker compose down
rm -rf windows-disk
```

Next `docker compose up -d` reinstalls Windows from scratch.

## If SSMS can't reach `host.lan,1433`

- Confirm `sql-lab` is running: `docker ps` should show it.
- Confirm it's listening: from Fedora, `ss -tlnp | grep 1433`.
- Fedora's firewall occasionally interferes with traffic from Docker's
  virtual networks. If the above both check out but the connection still
  times out, check `sudo firewall-cmd --list-all` for the zone covering
  your Docker bridge interface and make sure 1433/tcp isn't being dropped.
