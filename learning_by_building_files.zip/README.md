# RSVP System

A simple yet complete CRUD application for managing event RSVPs, built in Go.

## Project Structure

```
rsvp-system/
├── main.go          # CLI entry point and command handlers
├── models.go        # Data models (Event, Attendee, RSVPResult)
├── store.go         # In-memory event store with CRUD operations
├── utils.go         # Utility functions (ID generation)
└── go.mod           # Go module definition
```

## Features

- **Create Events**: Add new events with name, date, and description
- **Manage RSVPs**: Add, update, or remove attendee responses (yes/no/maybe)
- **View Events**: List all events or get details of a specific event
- **Get Results**: Aggregate RSVP statistics for any event
- **Thread-Safe**: Uses mutexes in the store for concurrent access

## Key Go Learning Points

This scaffold teaches you:

1. **Struct Organization**: Separating data models, business logic, and CLI handling
2. **Pointers & References**: Understanding when to use `*Event` vs `Event`
3. **Error Handling**: Returning errors explicitly with `error` type
4. **Concurrency Primitives**: Using `sync.RWMutex` for thread-safe access
5. **Methods**: Receiver functions on types (e.g., `func (e *Event) FindAttendee`)
6. **Interfaces**: Time to add these for persistence (database, JSON files)
7. **Slicing**: Managing attendee lists with append/indexing
8. **Maps**: Storing events by ID for fast lookup

## Setup

```bash
# Navigate to the project directory
cd rsvp-system

# Build the binary
go build

# Run the application
./rsvp-system
```

## Usage

Once running, you'll see a CLI prompt:

```
=== RSVP System ===
Commands: create-event, list-events, view-event, rsvp, remove-rsvp, results, quit

> create-event
Event name: Team Lunch
Event date (YYYY-MM-DD): 2024-12-20
Event description: Monthly team gathering at the cafe
Event created with ID: a7k2m9z1

> list-events
=== Events ===
[a7k2m9z1] Team Lunch - 2024-12-20

> rsvp a7k2m9z1 Alice yes
Alice has RSVP'd 'yes' to the event.

> rsvp a7k2m9z1 Bob maybe
Bob has RSVP'd 'maybe' to the event.

> rsvp a7k2m9z1 Charlie no
Charlie has RSVP'd 'no' to the event.

> view-event a7k2m9z1
=== Team Lunch ===
ID: a7k2m9z1
Date: 2024-12-20
Description: Monthly team gathering at the cafe
Total attendees: 3

Attendees:
  - Alice: yes
  - Bob: maybe
  - Charlie: no

> results a7k2m9z1
=== RSVP Results ===
Yes: 1
No: 1
Maybe: 1
Total: 3

> quit
Goodbye!
```

## Next Steps to Extend This

### 1. **Add Persistence**
- Save/load events from JSON files
- Integrate SQLite database
- Create an `interface` for storage backends

### 2. **Build a REST API**
- Use Gin or Echo framework
- Convert CLI commands to HTTP endpoints
- Add proper HTTP error handling

### 3. **Add Testing**
- Write unit tests for the store
- Test RSVP logic with table-driven tests
- Practice `testing` package

### 4. **Improve CLI**
- Use a library like `cobra` for better command structure
- Add input validation
- Improve error messages

### 5. **Add Web Frontend**
- Build a simple HTML/JavaScript interface
- Serve it from your Go server
- Connect to the REST API

## Code Highlights

### Thread-Safe Store
```go
func (es *EventStore) AddRSVP(eventID, attendeeName, status string) error {
    es.mu.Lock()          // Acquire write lock
    defer es.mu.Unlock()  // Release on return
    
    event, found := es.events[eventID]
    // ... business logic
}
```

### Error Handling
```go
event, found := store.GetEvent(eventID)
if !found {
    return fmt.Errorf("event not found")  // Explicit error
}
```

### Slicing & Removal
```go
// Find attendee index
idx, _, found := event.FindAttendee(attendeeName)
if found {
    // Remove by slicing
    event.Attendees = append(event.Attendees[:idx], event.Attendees[idx+1:]...)
}
```

## Questions to Answer as You Code

1. Why use `sync.RWMutex` instead of a simple `sync.Mutex`?
2. When should you use pointers vs values for function receivers?
3. How would you make the store database-agnostic with an interface?
4. What happens if two goroutines try to RSVP simultaneously?
5. How would you test the concurrent access?

Have fun building! 🚀
